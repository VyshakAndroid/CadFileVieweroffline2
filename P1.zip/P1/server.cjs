const { resolve } = require('path');
const { exec } = require('child_process');
const { tmpdir } = require('os');
const fs = require('fs');
const { randomUUID } = require('crypto');
const express = require('express');

const app = express();

// Serve static files from the 'dist' directory
app.use(express.static(resolve(__dirname, 'dist')));

// Ensure raw body parsing for the DWG converter API
app.post('/api/convert-dxf-to-dwg', express.raw({ type: '*/*', limit: '50mb' }), (req, res) => {
    try {
        const dxfContent = req.body.toString('utf-8');
        const uid = randomUUID();
        const inDir = resolve(tmpdir(), `oda_in_${uid}`);
        const outDir = resolve(tmpdir(), `oda_out_${uid}`);

        fs.mkdirSync(inDir, { recursive: true });
        fs.mkdirSync(outDir, { recursive: true });

        const dxfFile = resolve(inDir, 'drawing.dxf');
        const dwgFile = resolve(outDir, 'drawing.dwg');

        fs.writeFileSync(dxfFile, dxfContent);

        // Path to ODAFileConverter in typical Windows installation
        const odaPath = '"C:\\Program Files\\ODA\\ODAFileConverter 27.1.0\\ODAFileConverter.exe"';

        // ODAFileConverter Syntax: 
        // ODAFileConverter <Input Directory> <Output Directory> <Version> <Output Format> <Recurse> <Audit>
        const cmd = `${odaPath} "${inDir}" "${outDir}" "ACAD2018" "DWG" "0" "1"`;

        exec(cmd, (error, stdout, stderr) => {
            if (error) {
                console.error('ODA Conversion Error:', error, stderr);
                res.status(500).send('Conversion failed: ' + stderr);
                // Cleanup
                fs.rmSync(inDir, { recursive: true, force: true });
                fs.rmSync(outDir, { recursive: true, force: true });
                return;
            }

            if (fs.existsSync(dwgFile)) {
                const dwgBuffer = fs.readFileSync(dwgFile);
                res.setHeader('Content-Type', 'application/acad');
                res.setHeader('Content-Disposition', 'attachment; filename="drawing.dwg"');
                res.send(dwgBuffer);
                // Cleanup only on success
                fs.rmSync(inDir, { recursive: true, force: true });
                fs.rmSync(outDir, { recursive: true, force: true });
            } else {
                const errFile = resolve(outDir, 'drawing.err');
                let errMsg = 'Output DWG not found. ODA Converter failed silently.\n';
                if (fs.existsSync(errFile)) {
                    errMsg += '\nAudit Log:\n' + fs.readFileSync(errFile, 'utf-8');
                }
                try {
                    const outFiles = fs.readdirSync(outDir);
                    errMsg += '\nFiles in outDir: ' + outFiles.join(', ');
                } catch (e) { }
                res.status(500).send(errMsg);
                // Deliberately not cleaning up on failure for debugging
            }
        });
    } catch (e) {
        console.error('Error in /api/convert-dxf-to-dwg:', e);
        res.status(500).send('Internal Server Error: ' + e.message);
    }
});

// Fallback all other GET requests to index.html to support client-side routing
app.use((req, res) => {
    res.sendFile(resolve(__dirname, 'dist/index.html'));
});

// iisnode passes the port as an environment variable
const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
